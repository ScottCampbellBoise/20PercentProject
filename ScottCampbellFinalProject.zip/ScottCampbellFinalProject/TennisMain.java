import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
/**
 * Write a description of class TennisMain here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TennisMain implements ActionListener
{
    private static JFrame frame;
    private JFrame gameFrame;
    
    private JButton onePlayerButton;
    private JButton twoPlayerButton;
    private JButton optionsButton;

    private JButton colorButton;
    private JButton difficultyButton;
    private JButton returnButton;

    private JButton easyButton;
    private JButton normalButton;
    private JButton hardButton;

    private JTextField colorField;
    private JPanel colorPanel;

    private final int easy = 1;
    private final int normal = 2;
    private final int hard = 3;

    private Color gameColor = Color.white;
    private int gameDifficulty = normal;
    private BufferedImage gameImage;

    private boolean isImage = false;
    private boolean isColor = true;
    public static void main(String[] args){ 
        TennisMain tennisPanel = new TennisMain();
    }

    public TennisMain(){
        frame = new JFrame("Tennis Tour Pro");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        frame.setSize(500, 500);
        frame.setVisible(true);
        frame.setResizable(false);

        setUpInitialButtons();
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource().equals(onePlayerButton) )
        {
            removeInitialButtons();
            OnePlayer onePlayer = null;
            if(isImage)
            {
                onePlayer = new OnePlayer(gameDifficulty, gameImage);
            }
            else
            {
                onePlayer = new OnePlayer(gameDifficulty, gameColor);
            }
            gameFrame = new JFrame("Tennis Tour Pro: One Player Game");
            gameFrame.setSize(900,800);
            gameFrame.add(onePlayer, BorderLayout.CENTER);
            gameFrame.setVisible(true);
            gameFrame.setResizable(false);
            gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }
        else if(e.getSource().equals(twoPlayerButton) )
        {
            removeInitialButtons();
        }
        else if(e.getSource().equals(optionsButton) )
        {
            removeInitialButtons();
            setUpGameOptionButtons();
        }
        else if(e.getSource().equals(colorButton) )
        {
            removeGameOptionButtons();
            setUpColorTextField();
        }
        else if(e.getSource().equals(difficultyButton) )
        {
            removeGameOptionButtons();
            setUpGameDifficultyButtons();
        }
        else if(e.getSource().equals(returnButton) )
        {
            
        }
        else if(e.getSource().equals(colorField) )
        {
            String text = colorField.getText();
            colorField.selectAll();

            findColor(text);
            JLabel inputLabel = new JLabel("You Entered: "+text);
            inputLabel.setBounds(50,150,300,30);
            colorPanel.add(inputLabel);
            inputLabel.setVisible(true);

            frame.remove(colorPanel);
            frame.remove(colorField);
            //remove all the mesages
            setUpInitialButtons();
        }
        else if(e.getSource().equals(easyButton) )
        {
            gameDifficulty = easy;
        }
        else if(e.getSource().equals(normalButton) )
        {
            gameDifficulty = normal;
        }
        else if(e.getSource().equals(hardButton) )
        {
            gameDifficulty = hard;
        }
    }

    public void setUpInitialButtons(){
        onePlayerButton = new JButton();
        onePlayerButton.setText("One Player");
        frame.add(onePlayerButton);
        onePlayerButton.setBounds(50,50,150,30);
        onePlayerButton.addActionListener(this);

        twoPlayerButton = new JButton();
        twoPlayerButton.setText("Two Players");
        frame.add(twoPlayerButton);
        twoPlayerButton.setBounds(50,100,150,30);
        twoPlayerButton.addActionListener(this);

        optionsButton = new JButton();
        optionsButton.setText("Game Options");
        frame.add(optionsButton);
        optionsButton.setBounds(50,150,150,30);
        optionsButton.addActionListener(this);

        returnButton = new JButton();
        returnButton.setText("Return to Main");
        frame.add(returnButton);
        returnButton.setBounds(50,350,150,30);
        returnButton.addActionListener(this);
    }

    public void removeInitialButtons(){
        frame.remove(onePlayerButton);
        frame.remove(twoPlayerButton);
        frame.remove(optionsButton);
    }

    public void setUpGameOptionButtons(){
        colorButton = new JButton();
        colorButton.setText("Change Background");
        frame.add(colorButton);
        colorButton.setBounds(50,50,150,30);
        colorButton.addActionListener(this);

        difficultyButton = new JButton();
        difficultyButton.setText("Difficulty");
        frame.add(difficultyButton);
        difficultyButton.setBounds(50,100,150,30);
        difficultyButton.addActionListener(this);

        returnButton = new JButton();
        returnButton.setText("Return to Main");
        frame.add(returnButton);
        returnButton.setBounds(50,350,150,30);
        returnButton.addActionListener(this);
    }

    public void removeGameOptionButtons(){
        frame.remove(colorButton);
        frame.remove(difficultyButton);
    }

    public void setUpColorTextField(){
        JLabel colorFieldMsg = new JLabel("Enter an Image Pathway, Color, or Red, Green and Blue concentrations '_________'.");
        colorFieldMsg.setBounds(0,50,500,30);
        colorFieldMsg.setVisible(true);

        colorField = new JTextField(10);
        colorField.setHorizontalAlignment(JTextField.CENTER);
        colorField.addActionListener(this);

        colorPanel = new JPanel();
        frame.add(colorPanel);
        colorPanel.add(colorField);
        frame.setVisible(true);
        colorPanel.add(colorFieldMsg);

        returnButton = new JButton();
        returnButton.setText("Return to Main");
        frame.add(returnButton);
        returnButton.setBounds(50,350,150,30);
        returnButton.addActionListener(this);
    }

    public void findColor(String input)
    {
        if(input.toLowerCase().equals("red")){gameColor = Color.red; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("green")){gameColor = Color.green; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("blue")){gameColor = Color.blue; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("yellow")){gameColor = Color.yellow; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("orange")){gameColor = Color.orange; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("black")){gameColor = Color.black; isColor = true; isImage = false;}
        else if(input.toLowerCase().equals("white")){gameColor = Color.white; isColor = true; isImage = false;}
        else
        {
            try
            {
                int redConc = Integer.parseInt(input.substring(0,3));
                int greenConc = Integer.parseInt(input.substring(3,6));
                int blueConc = Integer.parseInt(input.substring(6,9));
                gameColor = new Color(redConc,greenConc,blueConc);
                isColor = true; 
                isImage = false;
            }
            catch(IndexOutOfBoundsException e)
            {
                JLabel errorMessage = new JLabel("Did not Recognize the Number Format. Please try again.");
                errorMessage.setBounds(50,200,300,30);
                errorMessage.setVisible(true);
                colorPanel.add(errorMessage);
            }
            catch(NumberFormatException e)
            {
                JLabel errorMessage = new JLabel("Did not Recognize the Number Format. Please try again.");
                errorMessage.setBounds(50,200,300,30);
                errorMessage.setVisible(true);
                colorPanel.add(errorMessage);
            }
            try
            {
                BufferedImage gameImage = null;
                gameImage = ImageIO.read(new File(input));
                isColor = false; 
                isImage = true;
            }
            catch(IOException e)
            {
                JLabel errorMessage = new JLabel("Did not recognize the image Pathway... make sure it is complete.");
                errorMessage.setBounds(50,200,300,30);
                errorMessage.setVisible(true);
                colorPanel.add(errorMessage);
            }
        }
    }

    public void setUpGameDifficultyButtons()
    {
        JButton hardButton = new JButton();
        hardButton.setText("Hard");
        hardButton.setBounds(50,50,100,30);
        frame.add(hardButton);
        hardButton.addActionListener(this);

        JButton normalButton = new JButton();
        normalButton.setText("Normal");
        normalButton.setBounds(50,100,100,30);
        frame.add(normalButton);
        normalButton.addActionListener(this);

        JButton easyButton = new JButton();
        easyButton.setText("Easy");
        easyButton.setBounds(50,150,100,30);
        frame.add(easyButton);
        easyButton.addActionListener(this);

        returnButton = new JButton();
        returnButton.setText("Return to Main");
        frame.add(returnButton);
        returnButton.setBounds(50,350,150,30);
        returnButton.addActionListener(this);
    }
}

